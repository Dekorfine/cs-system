-- ════════════════════════════════════════════════════════════════════
-- fix21: 产品维护 (products 表) + 网站维护配置 (复用 system_settings)
-- 跑这个 SQL 一次,然后进客服系统 → ⚙ 设置 → 📦 产品 / 🌐 网站
-- ════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  sku TEXT,                                     -- 产品编号(可空,但建议填)
  name TEXT NOT NULL,                           -- 产品名 *
  category TEXT,                                -- lighting/furniture/accessories/lampshade/parts/other
  supplier_id TEXT,                             -- 关联 suppliers.id
  supplier_name TEXT,                           -- 供应商名快照
  default_unit_price NUMERIC,                   -- 默认单价
  default_currency TEXT DEFAULT 'USD',          -- USD/CNY/EUR/GBP/AUD
  image TEXT,                                   -- 产品图 (data URL base64)
  url TEXT,                                     -- 产品链接
  description TEXT,                             -- 规格 / 材质 / 尺寸
  tags TEXT,                                    -- 标签 (黄铜, 古典, 客厅)
  notes TEXT,                                   -- 内部备注
  total_aftersales INT DEFAULT 0,               -- 售后次数(fix22 会自动统计)
  applicable_sites TEXT,                        -- 适用网站(逗号分隔代码,可留空)
  created_by TEXT,
  created_by_name TEXT,
  created_at_ms BIGINT DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted BOOLEAN DEFAULT FALSE,
  deleted_at BIGINT,
  deleted_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_products_sku        ON products(sku) WHERE deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_products_name       ON products(name) WHERE deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_products_supplier   ON products(supplier_id) WHERE deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_products_category   ON products(category) WHERE deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_products_updated_at ON products(updated_at DESC) WHERE deleted = FALSE;

-- 行级安全
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "products_select" ON products;
CREATE POLICY "products_select" ON products FOR SELECT USING (true);

DROP POLICY IF EXISTS "products_insert" ON products;
CREATE POLICY "products_insert" ON products FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "products_update" ON products;
CREATE POLICY "products_update" ON products FOR UPDATE USING (true);

DROP POLICY IF EXISTS "products_delete" ON products;
CREATE POLICY "products_delete" ON products FOR DELETE USING (true);

-- Realtime — 任何主管增删产品,所有客服实时同步
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE products;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- ════════════════════════════════════════════════════════════════════
-- 网站维护无需建表 — 复用 system_settings 表,key='custom_sites',value=JSONB
-- 默认是空数组 [],第一次添加时自动创建那一行
-- ════════════════════════════════════════════════════════════════════

-- ✅ 完成 · 现在打开客服系统 → ⚙ 设置 → 📦 产品 / 🌐 网站
